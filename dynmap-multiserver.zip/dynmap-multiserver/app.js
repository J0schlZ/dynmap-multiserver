"use strict";

var express = require('express');
var request = require('request-promise');

const version = '1.0.0-SNAPSHOT';

const config = {
    mapList: {
        'lobby':      'https://map.craft.together.de/lobby/',
        'freebuild1': 'https://map.craft.together.de/freebuild1/',
        'freebuild2': 'https://map.craft.together.de/freebuild2/',
        'dev':        'https://map.craft.together.de/dev/'
    }
};

class DynmapMultiserver {
    constructor(config) {
        this.app = express();

        this.config = config;
        this.dynmapConfig = null;

        this.app.use('/', express.static('./public'));
        this.app.get('/standalone/*', this.route);

        this.getConfiguration("lobby").then(configuration => {
            this.config = configuration[0];
            this.dynmapConfig = configuration[1];

            app.listen(8123, function () {
                console.log('MultiMap v' + version + ' started.');
            });
        });
    }

    async getConfiguration(configMap) {
        let config = await this.getConfig(configMap),
            dynmapConfig = {};

        for (let mapName in this.config.mapList)
            dynmapConfig[mapName] = await this.getDynmapConfig(this.config.mapList[mapName]);

        return [config, dynmapConfig];
    }

    route(req, res) {
        switch (req.params[0]) {
            case "config.js":
                res.end(this.config);
                break;
        }
    }

    getConfig(mapName) {
        return new Promise((resolve, reject) => {
            request(this.config.mapList[mapName] + 'standalone/config.js')
                .then(function (response) {
                    let config = {}, lines = response.replace(/\r\n/g, '\n').split('\n');

                    for (let i in lines) {
                        let match = /([a-z_]{1,}):\s'(.*)',?/gi.exec(lines[i]);
                        if (!match) continue;
                        config[match[1]] = match[2];
                    }

                    resolve(config);
                })
                .catch(function (err) {
                    reject(err);
                });
        });
    }

    getDynmapConfig(configUrl) {
        return new Promise((resolve, reject) => {
            request(configUrln)
                .then(function (response) {
                    let dynmapConfig = null;

                    try {
                        dynmapConfig = JSON.parse(response);
                    } catch (err) {
                        console.log(err);
                    }

                    if (dynmapConfig)
                        resolve(dynmapConfig);
                    else
                        reject(new Error('Error: failed parsing "' + configUrl + '"'));
                })
                .catch(function (err) {
                    reject(err);
                });
        });
    }
}

new DynmapMultiserver(config);